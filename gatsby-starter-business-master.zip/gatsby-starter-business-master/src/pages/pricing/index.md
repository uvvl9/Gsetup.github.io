---
templateKey: pricing-page
title: Pricing
meta_title: Pricing | Gatsby Starter Business
meta_description: >-
  Cum sociis natoque penatibus et magnis dis parturient montes, nascetur
  ridiculus mus. Aenean eu leo quam. Pellentesque ornare sem lacinia quam
  venenatis vestibulum. Sed posuere consectetur est at lobortis. Cras mattis
  consectetur purus sit amet fermentum.
pricing:
  description: >-
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec porta justo justo, 
    non semper odio cursus in. Curabitur ligula tortor, tristique non odio nec, imperdiet 
    mattis leo. Vivamus aliquam rhoncus tortor vitae convallis. Aliquam non dui nibh. Nam 
    a velit at enim sagittis pellentesque.
  heading: Monthly subscriptions
  plans:
    - description: Nulla faucibus, leo a condimentum aliquam, libero leo vehicula arcu
      items:
        - Lorem ipsum dolor sit amet
        - consectetur adipiscing elit
        - Nunc finibus sem a sem ultrices
      plan: Pro
      price: '50'
    - description: Mauris vitae dolor eu mauris malesuada cursus.
      items:
        - eget sagittis magna tempor
        - Quisque pulvinar lorem molestie
        - Proin at sagittis ex
      plan: Enterprise
      price: '80'
    - description: Praesent elit lectus, iaculis vel odio vitae, bibendum auctor lacus.
      items:
        - Pellentesque luctus neque id mauris accumsan
        - nec imperdiet justo eleifend
        - Sed eget ornare orci
      plan: Custom
      price: '??'
---

